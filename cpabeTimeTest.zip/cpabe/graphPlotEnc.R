data_cpabe <- read.csv("/home/ayan/workspace/cpabe/enc_cpabe.csv")
data_cbabe <- read.csv("/home/ayan/workspace/cpabe/enc_cbabe.csv")
data_taabe <- read.csv("/home/ayan/workspace/cpabe/enc_taabe.csv")
data_ooabe <- read.csv("/home/ayan/workspace/cpabe/enc_ooabe.csv")
data_cpabe
data_cbabe
data_taabe
data_ooabe
png(file = "/home/ayan/workspace/cpabe/enc.jpg")

# Plot the bar chart.
plot(data_cbabe,type = "o",col = "red", xlab = "Number Of attribute", ylab = "Time taken For encryption", 
     main = "Encryption time complexity")
lines(data_cpabe, type = "o",col = "blue")
lines(data_taabe, type = "o",col = "black")


lines(data_ooabe, type = "o",col = "green")
#text(labels=c("cpabe","cbabe"))
# Save the file.
dev.off()
#colors()

