data_cpabe <- read.csv("/home/ayan/workspace/cpabe/dec_cpabe.csv")
data_cbabe <- read.csv("/home/ayan/workspace/cpabe/dec_cbabe.csv")
data_taabe <- read.csv("/home/ayan/workspace/cpabe/dec_taabe.csv")
data_ooabe <- read.csv("/home/ayan/workspace/cpabe/dec_ooabe.csv")
data_cpabe
data_cbabe
data_taabe
data_ooabe
png(file = "/home/ayan/workspace/cpabe/dec.jpg")

# Plot the bar chart.
plot(data_ooabe,type = "o",col = "red", xlab = "Number Of attribute", ylab = "Time taken For decryption(ms)", 
     main = "Decryption time complexity(ms) Vs number of attributes")
lines(data_taabe, type = "o",col = "green")
lines(data_cpabe, type = "o",col = "blue")

lines(data_cbabe, type = "o",col = "black")
#text(labels=c("cpabe","cbabe"))
# Save the file.
dev.off()
#colors()

