data_cpabe <- read.csv("/home/ayan/workspace/cpabe/size_cpabe.csv")
data_cbabe <- read.csv("/home/ayan/workspace/cpabe/size_cbabe.csv")
data_taabe <- read.csv("/home/ayan/workspace/cpabe/size_taabe.csv")
data_ooabe <- read.csv("/home/ayan/workspace/cpabe/size_ooabe.csv")
data_cpabe
data_cbabe
data_taabe
data_ooabe
png(file = "/home/ayan/workspace/cpabe/size.jpg")

# Plot the bar chart.
plot(data_cbabe,type = "o",col = "red", xlab = "Number Of attribute", ylab = "Ciphertext Size in bytes", 
     main = "Ciphertext Size in bytes Vs number of attributes")
lines(data_taabe, type = "o",col = "green")
lines(data_cpabe, type = "o",col = "blue")

lines(data_ooabe, type = "o",col = "gray")
#text(labels=c("cpabe","cbabe"))
# Save the file.
dev.off()
colors()

