



import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class StoreCSV {
	PrintWriter pw=null;
	
    public StoreCSV(String Type) throws FileNotFoundException{
         pw = new PrintWriter(new File(Type+".csv"));
         StringBuilder    sb = new StringBuilder();
        sb.append("NumberOfAttribute");
        sb.append(',');
        sb.append("TimeTaken");
        sb.append('\n');
   
        pw.append(sb.toString());
       
        System.out.println("done!");
    }
    public void addRow(double tt,double sa){
    	StringBuilder    sb = new StringBuilder();
    	sb.append(sa);
        sb.append(',');
        sb.append(tt);
        sb.append('\n');
        pw.append(sb.toString());
    }
    public void closeFile(){
    	 pw.close();
    }
}