import java.io.FileNotFoundException;
import java.math.BigInteger;

import it.unisa.dia.gas.jpbc.*;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;
import it.unisa.dia.gas.plaf.jpbc.pbc.curve.PBCTypeACurveGenerator;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;
import it.unisa.dia.gas.plaf.jpbc.pbc.curve.PBCTypeA1CurveGenerator;

public class TimeTestDec {

//static double et=1.8,e1=16,mt=0.01,m1=0.07,dt=0.04,sz=0.0,mz=0.0,sa,sat,san,sd,sdt,sdn,p=21,h=12,Penc;//for type a pairig


static double et=26.0,e1=303,mt=0.04,m1=0.29,dt=0.07,sz=0.0,mz=0.0,sa,sat,san,sd,sdt,sdn,p=268,h=12,Penc;//for type a1 pairig

	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		//typeA1Pairing();
	
		//cpabe();
		cbAbe();
		taAbe();
		ooAbe();
		//typeAPairing();
		//typeA1Pairing2();
	}
    private static void ooAddrow(StoreCSV scsv, double i,double enc) throws FileNotFoundException{
		
    	Penc=enc;
		sdt=i/2;
		sdn=i-sdt;
		double timeU=2*dt+p+e1+m1;
		double timeP=sdt*(3*mt+4*p+2*dt)+sdn*(mt+dt+2*p)+Penc           +2*p+dt+mt+sz*sdt+sdt*mt;
		double timeD=sdt*(7*e1+10*m1+h+4*p+2*et)+sdn*(mt+dt+2*p)+Penc;
		scsv.addRow(timeU+timeP+timeD, i);
	}
	private static void ooAbe() throws FileNotFoundException {
		StoreCSV scsv=new StoreCSV("dec_ooabe");
		ooAddrow(scsv,0,1);
		ooAddrow(scsv,3,87);
		ooAddrow(scsv,6,176);
		ooAddrow(scsv,9,274);
		ooAddrow(scsv,12,362);
		ooAddrow(scsv,14,428);
		ooAddrow(scsv,18,544);
		ooAddrow(scsv,19,570);
		ooAddrow(scsv,27,823);
		scsv.closeFile();
		
	}
	//==================================================
	private static void taAddrow(StoreCSV scsv, double i,double enc) throws FileNotFoundException{
		
		Penc=enc;
		sdt=i/2;
		sdn=i-sdt;
		double timeU=2*dt+p+e1+m1;
		double timeP=sdt*(3*mt+4*p+2*dt)+sdn*(mt+dt+2*p)+Penc;
		double timeD=sdt*(7*e1+10*m1+h+4*p+2*et)+sdn*(mt+dt+2*p)+Penc;
		scsv.addRow(timeU+timeP+timeD, i);
	}
	private static void taAbe() throws FileNotFoundException {
		StoreCSV scsv=new StoreCSV("dec_taabe");
		taAddrow(scsv,0,1);
		taAddrow(scsv,3,87);
		taAddrow(scsv,6,176);
		taAddrow(scsv,9,274);
		taAddrow(scsv,12,362);
		taAddrow(scsv,14,428);
		taAddrow(scsv,18,544);
		taAddrow(scsv,19,570);
		taAddrow(scsv,27,823);
		scsv.closeFile();
		
	}
	//================================================
	private static void cbAddrow(StoreCSV scsv, double i,double enc) throws FileNotFoundException{
		sd=i;
		Penc=enc;
		double timeU=dt+p+e1+m1;
		double timeP=et*Penc+2*p*sd;
		scsv.addRow(timeU+timeP, sd);
	}
	private static void cbAbe() throws FileNotFoundException {
		StoreCSV scsv=new StoreCSV("dec_cbabe");
		cbAddrow(scsv,0,1);
		cbAddrow(scsv,3,87);
		cbAddrow(scsv,6,176);
		cbAddrow(scsv,9,274);
		cbAddrow(scsv,12,362);
		cbAddrow(scsv,14,428);
		cbAddrow(scsv,18,544);
		cbAddrow(scsv,19,570);
		cbAddrow(scsv,27,823);
		scsv.closeFile();
		
	}
	//======================================================
	private static void cpabeAddrow(StoreCSV scsv, double i,double enc) throws FileNotFoundException{
		sd=i;
		Penc=enc;
		double time=2*p*sd+et*Penc+2*dt+p;
		scsv.addRow(time, sd);
	}
	private static void cpabe() throws FileNotFoundException {
		StoreCSV scsv=new StoreCSV("dec_cpabe");
		cpabeAddrow(scsv,0,0);
		cpabeAddrow(scsv,3,87);
		cpabeAddrow(scsv,6,176);
		cpabeAddrow(scsv,9,273);
		cpabeAddrow(scsv,12,358);
		cpabeAddrow(scsv,14,417);
		cpabeAddrow(scsv,18,521);
		cpabeAddrow(scsv,19,557);
		cpabeAddrow(scsv,27,787);
		scsv.closeFile();
		
	}
	
	
	private static void typeA1Pairing2() {
		

		// JPBC Type A1 pairing generator...
		TypeA1CurveGenerator pg = new TypeA1CurveGenerator(
		    2,  // the number of primes
		    517 // the bit length of each prime
		);
		PairingParameters a=pg.generate();

Pairing p = PairingFactory.getPairing(a);
Field G1 = p.getGT();
Field g1=p.getZr();
Element e1 = G1.newRandomElement();
Element e2 = G1.newRandomElement();
long strt=System.currentTimeMillis();
//Element out = p.pairing(e1, e2);
long end=System.currentTimeMillis();
//System.out.println(out);
System.out.println("time taken for A1 pairing "+(end-strt));	
//allOperation(p);
//===========================================
long ti=0;
for(int i=1;i<100;i++)
ti=ti+ExpOperation(p,G1);
System.out.println(ti+" avg time to exp "+(ti/100.0));

//===========================================
ti=0;
for(int i=1;i<100;i++)
ti=ti+AddOperation(p,G1);
System.out.println(ti+" avg time to add "+(ti/100.0));
//==============================================
ti=0;

for(int i=1;i<100;i++)
ti=ti+MultiOperation(p,G1);
System.out.println(ti+" avg time to multiply "+(ti/100.0));
//========================================================
ti=0;

for(int i=1;i<100;i++)
ti=ti+SumZ1Operation(p,g1);
System.out.println(ti+" avg time to add Zr "+(ti/100.0));
//================================================
ti=0;

for(int i=1;i<100;i++)
ti=ti+divOperation(p,G1);
System.out.println(ti+" avg time to div "+(ti/100.0));
//========================================================

		
	}
	private static void typeAPairing() {

int rBits = 160;
int qBits = 512;

		// JPBC Type A pairing generator...
		TypeACurveGenerator pg = new TypeACurveGenerator(rBits, qBits);
		PairingParameters a=pg.generate();

Pairing p = PairingFactory.getPairing(a);
Field G1 = p.getGT();
Field g1=p.getZr();
g1.newRandomElement();
Element e1 = G1.newRandomElement();
Element e2 = G1.newRandomElement();
long strt=System.currentTimeMillis();
//Element out = p.pairing(e1, e2);
long end=System.currentTimeMillis();
System.out.println("time taken for A pairing "+(end-strt));
long ti=0;
for(int i=1;i<100;i++)
ti=ti+ExpOperation(p,G1);
System.out.println(ti+" avg time to exp "+(ti/100.0));
//===========================================
ti=0;
for(int i=1;i<100;i++)
ti=ti+AddOperation(p,G1);
System.out.println(ti+" avg time to add "+(ti/100.0));
//==============================================
ti=0;

for(int i=1;i<100;i++)
ti=ti+MultiOperation(p,G1);
System.out.println(ti+" avg time to multiply "+(ti/100.0));
//========================================================
ti=0;

for(int i=1;i<100;i++)
ti=ti+SumZ1Operation(p,g1);
System.out.println(ti+" avg time to add Zr "+(ti/100.0));
		
	}
	private static long ExpOperation(Pairing p,Field G1) {
		
			Element ex=		p.getZr().newElement();
			ex.setToRandom();
		Element e1 = G1.newRandomElement();
		
		long strt=System.currentTimeMillis();
		e1.powZn(ex);
		long end=System.currentTimeMillis();
		//System.out.println("time taken for add "+(end-strt));
	return (end-strt);
		
	}
	private static long AddOperation(Pairing p,Field G1) {
		

		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		System.out.println(e1);
		long strt=System.currentTimeMillis();
		e1.add(e2);
		long end=System.currentTimeMillis();
		//System.out.println("time taken for add "+(end-strt));
	return (end-strt);
		
	}
private static long divOperation(Pairing p,Field G1) {
		

		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		System.out.println(e1);
		long strt=System.currentTimeMillis();
		e1.div(e2);
		long end=System.currentTimeMillis();
		//System.out.println("time taken for add "+(end-strt));
	return (end-strt);
		
	}
	private static long MultiOperation(Pairing p,Field G1 ) {
		

		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		
		long strt=System.currentTimeMillis();
		e1.mul(e2);
		long end=System.currentTimeMillis();
		//System.out.println("time taken for multiply "+(end-strt));
		return end-strt;
		
	}
private static long SumZ1Operation(Pairing p,Field G1 ) {
		

		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		//System.out.println("e1 is "+e1+" e2 is "+e2);
		long strt=System.currentTimeMillis();
		e1.add(e2);
		long end=System.currentTimeMillis();
		//System.out.println("time taken for multiply "+(end-strt));
		return end-strt;
		
	}
	/*
	private static void typeA1Pairing() {

		Pairing p = PairingFactory.getPairing("a1.param");
		Field G1 = p.getG1();
		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		long strt=System.currentTimeMillis();
		Element out = p.pairing(e1, e2);
		long end=System.currentTimeMillis();
		System.out.println(out);
		
		
		System.out.println("time taken for pairing "+(end-strt));
		
	}*/

}
