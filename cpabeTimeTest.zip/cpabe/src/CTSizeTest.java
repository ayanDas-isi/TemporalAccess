import java.io.FileNotFoundException;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Field;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.jpbc.PairingParameters;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;
import it.unisa.dia.gas.plaf.jpbc.pairing.a.TypeACurveGenerator;
import it.unisa.dia.gas.plaf.jpbc.pairing.a1.TypeA1CurveGenerator;


public class CTSizeTest {

	
	static int gt=262,g1=262,sa,tao,san,sat,zp=130;
	
	public static void main(String[] args) throws FileNotFoundException {
	
		// typeAPairing();
		//typeA1Pairing2();
		 //cpabe();
		cbabe();
		taabe();
		ooabe();
	}
	private static void typeAPairing() {

		int rBits = 160;
		int qBits = 512;

				// JPBC Type A pairing generator...
				TypeACurveGenerator pg = new TypeACurveGenerator(rBits, qBits);
				PairingParameters a=pg.generate();

		Pairing p = PairingFactory.getPairing(a);
		Field GT = p.getGT();
		Field G1 = p.getG1();
		Field g=p.getZr();
		g.newRandomElement();
		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		gt=GT.getLengthInBytes();
		g1=G1.getLengthInBytes();
		zp=g.getLengthInBytes();
		System.out.println("gt "+gt+" g1 "+g1+" zp "+zp);
			}
	private static void cpabe() throws FileNotFoundException{
		StoreCSV scsv=new StoreCSV("size_cpabe");
		cpabeAddrow(scsv,0,0);
		cpabeAddrow(scsv,3,1560);
		cpabeAddrow(scsv,6,3120);
		cpabeAddrow(scsv,9,4680);
		cpabeAddrow(scsv,12,6240);
		cpabeAddrow(scsv,14,7280);
		cpabeAddrow(scsv,18,9360);
		cpabeAddrow(scsv,19,9880);
		cpabeAddrow(scsv,27,14040);
		scsv.closeFile();
	}
private static void cpabeAddrow(StoreCSV scsv, int i, int j) {
	tao=j;
	double size=gt+2*g1*i+tao;
	scsv.addRow(size, i);
		
	}
private static void cbabe() throws FileNotFoundException{
	StoreCSV scsv=new StoreCSV("size_cbabe");
	cbabeAddrow(scsv,0,0);
	cbabeAddrow(scsv,3,1560);
	cbabeAddrow(scsv,6,3120);
	cbabeAddrow(scsv,9,4680);
	cbabeAddrow(scsv,12,6240);
	cbabeAddrow(scsv,14,7280);
	cbabeAddrow(scsv,18,9360);
	cbabeAddrow(scsv,19,9880);
	cbabeAddrow(scsv,27,14040);
	scsv.closeFile();
}
private static void cbabeAddrow(StoreCSV scsv, int i, int j) {
tao=j;
double size=gt+g1*(1+4*i)+tao;
scsv.addRow(size, i);
	
}
private static void taabe() throws FileNotFoundException{
	StoreCSV scsv=new StoreCSV("size_taabe");
	taabeAddrow(scsv,0,0);
	taabeAddrow(scsv,3,1560);
	taabeAddrow(scsv,6,3120);
	taabeAddrow(scsv,9,4680);
	taabeAddrow(scsv,12,6240);
	taabeAddrow(scsv,14,7280);
	taabeAddrow(scsv,18,9360);
	taabeAddrow(scsv,19,9880);
	taabeAddrow(scsv,27,14040);
	scsv.closeFile();
}
private static void taabeAddrow(StoreCSV scsv, int i, int j) {
tao=j;
sat=i/2;
san=i-sat;
double size=gt+g1+g1*(4*sat+2*san)+tao;
scsv.addRow(size, i);
	
}
private static void ooabe() throws FileNotFoundException{
	StoreCSV scsv=new StoreCSV("size_ooabe");
	ooabeAddrow(scsv,0,0);
	ooabeAddrow(scsv,3,1560);
	ooabeAddrow(scsv,6,3120);
	ooabeAddrow(scsv,9,4680);
	ooabeAddrow(scsv,12,6240);
	ooabeAddrow(scsv,14,7280);
	ooabeAddrow(scsv,18,9360);
	ooabeAddrow(scsv,19,9880);
	ooabeAddrow(scsv,27,14040);
	scsv.closeFile();
}
private static void ooabeAddrow(StoreCSV scsv, int i, int j) {
tao=j;
sat=i/2;
san=i-sat;
double size=gt+g1+g1*(4*sat+2*san)+tao       +2*(zp*i);
scsv.addRow(size, i);
	
}
private static void typeA1Pairing2() {
		

		// JPBC Type A1 pairing generator...
		TypeA1CurveGenerator pg = new TypeA1CurveGenerator(
		    2,  // the number of primes
		    517 // the bit length of each prime
		);
		PairingParameters a=pg.generate();
		Pairing p = PairingFactory.getPairing(a);
		Field GT = p.getGT();
		Field G1 = p.getG1();
		Field g=p.getZr();
		g.newRandomElement();
		Element e1 = G1.newRandomElement();
		Element e2 = G1.newRandomElement();
		gt=GT.getLengthInBytes();
		g1=G1.getLengthInBytes();
		zp=g.getLengthInBytes();
		System.out.println("gt "+gt+" g1 "+g1+" zp "+zp);
	
	}

}
